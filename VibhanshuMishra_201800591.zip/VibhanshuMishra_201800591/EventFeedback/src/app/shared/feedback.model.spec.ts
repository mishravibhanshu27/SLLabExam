import { Feedback } from './feedback.model';

describe('Feedback', () => {
  it('should create an instance', () => {
    expect(new Feedback()).toBeTruthy();
  });
});
