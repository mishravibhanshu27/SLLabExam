export class Feedback {
    _id: string;
    username: string;
    category: string;
    budget: number;
    currentexpense:number;
};
