const mongoose = require('mongoose');

var Feedback = mongoose.model('Feedback',{
    username: { type: String },
    category: { type: String },
    budget: { type: Number },
    currentexpense:{ type: Number}   
});

module.exports = {Feedback};